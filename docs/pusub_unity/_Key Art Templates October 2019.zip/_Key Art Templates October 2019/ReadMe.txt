Asset Store Key Image Templates
Updated October 2019

* Icon Image - 160x160
* Card Image - 420x280
* Cover Image - 1950x1300
* Social Media Image - 1200x630
* Screenshots - Suggested resolution is 2048x1152. Minimum 1200 pixels wide, any height.

Notes:

1. Screenshots will be resized for display, but users will be able to view the full resolution.
2. Adding text/logos or other graphics onto Social Media Images may exclude your asset from being featured in social media campaigns.
3. Failure to follow logo/text guidance may exclude your asset from being featured on the home page.